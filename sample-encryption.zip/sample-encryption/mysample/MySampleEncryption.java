/*
 * (C) COPYRIGHT International Business Machines Corp. 2010,2011
 * All Rights Reserved
 * Licensed Materials - Property of IBM
 *
 * This sample program is provided AS IS and may be used, executed, copied
 * and modified without royalty payment by customer (a) for its own instruction and
 * study, (b) in order to develop applications designed to run with an IBM
 * WebSphere product, either for customer's own internal use or for
 * redistribution by customer, as part of such an application, in customer's
 * own products.
 *
 *
 */
package mysample;

import java.util.HashMap;

import com.ibm.wsspi.security.crypto.CustomPasswordEncryption;
import com.ibm.wsspi.security.crypto.EncryptedInfo;
import com.ibm.wsspi.security.crypto.PasswordDecryptException;
import com.ibm.wsspi.security.crypto.PasswordEncryptException;


/**
 * MySampleEncryption for custom encryption test
 *  
 */
public class MySampleEncryption implements CustomPasswordEncryption {

	static final String SHH_STRING = "Shh!-secret-"; 
	
	/* 
	 * @see com.ibm.wsspi.security.crypto.CustomPasswordEncryption#decrypt(com.ibm.wsspi.security.crypto.EncryptedInfo)
	 * This decrypt just takes away "Shh!-secret-" from the incoming string. 
	 */
	public byte[] decrypt(EncryptedInfo info) throws PasswordDecryptException {

		System.out.println("---Entering MySampleEncryption.decrypt()"); 
		byte[] decryptedBytes = null; 
		
		if (info != null ) {
		    String encrypted_string = new String(info.getEncryptedBytes());
		    if ((encrypted_string!=null) && (encrypted_string.startsWith(SHH_STRING))){
			String decrypted_string = encrypted_string.substring(SHH_STRING.length()); 
			System.out.println("encrypted_string=" + encrypted_string + 
					   " decrypted_string=" + decrypted_string); 
			decryptedBytes = decrypted_string.getBytes(); 
		    }
		    else {
			System.out.println("encrypted string was null or not starting with Shh!-secret-  encrypted_string=" + encrypted_string ); 
		    }
		}
		else {
		    System.out.println("info is null. Null bytes are returned"); 
		}
		System.out.println("---Exiting MySampleEncryption.decrypt()"); 
		return decryptedBytes; 
	}

	/* 
	 * @see com.ibm.wsspi.security.crypto.CustomPasswordEncryption#encrypt(byte[])
         * encrypt() only adds "Shh!-secret-" to the incoming string.
	 */
	public EncryptedInfo encrypt(byte[] decryptedBytes)
			throws PasswordEncryptException {
		
		System.out.println("---Entering MySampleEncryption.encrypt()"); 
		EncryptedInfo info = null; 
		
		if (decryptedBytes == null) {
			System.out.println("MySampleEncryption - decryptedBytes is null. null info will be returned");			
		} 
		else {
		    //String password = decryptedBytes.toString();
		    String password = new String(decryptedBytes); 
		    System.out.println("password=" + password);
		    String encrypted_password = SHH_STRING + password; 
		    System.out.println("encrypted_password=" + encrypted_password);
		    info = new EncryptedInfo(encrypted_password.getBytes(), null); 
		    
		}
		System.out.println("---Exiting MySampleEncryption.encrypt()"); 
		return info; 
	}

	/* 
	 * @see com.ibm.wsspi.security.crypto.CustomPasswordEncryption#initialize(java.util.HashMap)
	 */
	public void initialize(HashMap initializationData) {
		// TODO Auto-generated method stub
		System.out.println("Initializing MySampleEncryption!");

	}

	/* 
	 *  This is main program to run encrypt/decrypt one after another to see if works. 
	 */
    public static void main(String[] args) {
	
	if (args.length != 1) {
	    System.out.println("\n\n\nPlease enter one string.");
	} 
	else {
            MySampleEncryption mse = new MySampleEncryption(); 
            mse.initialize(new HashMap()); 

            String password = args[0];
	    String encrypted_password = null; 

	    System.out.println("\n\n\nStarting to test.....\n\n\n\nGoing to encrypt input string: " + password);
	    try {
	        EncryptedInfo info = mse.encrypt(password.getBytes()); 
		encrypted_password = new String(info.getEncryptedBytes()); 
		System.out.println("\n\n\nEncrypted password is: " + encrypted_password);
	    }
	    catch (Exception e) {
		System.out.println("\n\n\nException is caught from encrypt");
	    }

            System.out.println("\n\n\nNow decrypting .." + encrypted_password); 
	    try {
		byte[] decrypted_bytes = mse.decrypt(new EncryptedInfo(encrypted_password.getBytes(), null));
		System.out.println("\n\n\nDecrypted password is: " + new String(decrypted_bytes)); 
	    }
	    catch (Exception e) {
		System.out.println("\n\n\nException is caught from decrypt"); 
	    }

            System.out.println("\n\n\nTest is done!"); 
	}

    }
	

}
